Asenso Soluciones es un servicio de remodelaciones limpias y rápidas en la Gran Caracas (Caracas, Miranda y La Guaira).
Ofrecemos microcemento, drywall, resina epóxica y wallpaper con garantía escrita, precio cerrado y atención rápida por WhatsApp.

🚀 Preview 24h

Con nuestro servicio Asenso Preview 24h, combinamos experiencia en remodelaciones con Inteligencia Artificial:

Envías fotos y medidas de tu espacio.

En menos de 24 horas recibes un render con IA mostrando cómo quedaría.

Adjuntamos presupuesto preliminar y precio cerrado.

🛠️ Tecnologías usadas

Next.js → framework React para el frontend.

TailwindCSS → estilos rápidos, modernos y responsive.

Vercel → despliegue continuo con GitHub.

PWA básico → favicon, manifest y soporte para móviles.

📂 Estructura

pages/index.js → Landing principal (hero, servicios, portafolio, contacto).

styles/globals.css → configuración de Tailwind.

public/logo-asenso.png → logo circular.

public/fotos/ → imágenes de antes y después (coloca aquí tus fotos reales).

Favicons y manifest ya configurados (favicon-32.png, favicon-192.png, apple-touch-icon.png, site.webmanifest).

⚡ Instalación local
npm install
npm run dev
# abre http://localhost:3000

🌐 Deploy en Vercel

Conectar repositorio a GitHub.

Importar en Vercel
.

Framework detectado: Next.js.

Deploy automático → dominio .vercel.app.

📞 Contacto

WhatsApp: +58 412 301 5376

Instagram: @asenso_soluciones

TikTok: @asenso_soluciones
