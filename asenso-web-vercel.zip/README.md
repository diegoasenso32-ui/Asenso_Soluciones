# Asenso Soluciones — Landing (Next.js + Tailwind + Vercel)

Remodelaciones limpias y rápidas en Gran Caracas. Incluye Preview 24h con imágenes IA y CTA a WhatsApp.

## Requisitos
- Node.js 18+
- Cuenta en GitHub y Vercel

## Instalar
```bash
npm install
npm run dev
# http://localhost:3000
```

## Estructura
- `pages/index.js` — Landing principal
- `styles/globals.css` — Tailwind
- `public/logo-asenso.png` — logo circular
- `public/fotos/*` — reemplaza por tus ANTES/DESPUÉS
- Favicons + manifest en `public/`

## Deploy (GitHub → Vercel)
```bash
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin https://github.com/diegoasenso32-ui/Asenso_Soluciones.git
git push -u origin main
```
En Vercel: New Project → Importa el repo → Framework: Next.js → Deploy.

## Personaliza
- `PHONE` y `WHATSAPP_URL` en `pages/index.js`
- Colorea y copy en el mismo archivo
- Activa/Desactiva marca de agua cambiando `WATERMARK`
