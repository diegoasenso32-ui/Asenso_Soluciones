import Head from 'next/head'

export default function Home() {
  const PHONE = "+584123015376";
  const WHATSAPP_URL = `https://wa.me/${PHONE}?text=Hola%20Diego%2C%20quiero%20mi%20Preview%2024h%20para%20remodelar%20mi%20espacio.`;

  // marca de agua
  const WATERMARK = true;
  const LOGO_SRC = "/logo-asenso.png";
  const WM_OPACITY = 0.12;
  const WM_SIZE = 120;

  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-100">
      <Head>
        <title>Asenso Soluciones — Remodelaciones limpias y rápidas en Gran Caracas</title>
        <meta name="description" content="Microcemento, drywall, resina epóxica y wallpaper con garantía por escrito. Iluminación LED blanca fría y acabados modernos. Asenso Preview 24h: te mostramos con IA cómo quedaría tu espacio + presupuesto en 24 horas." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#0B1220" />
        <link rel="icon" href="/favicon-32.png" sizes="32x32" />
        <link rel="icon" href="/favicon-192.png" sizes="192x192" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "Asenso Soluciones",
              areaServed: ["Caracas", "Miranda", "La Guaira"],
              address: { "@type": "PostalAddress", addressLocality: "Caracas", addressCountry: "VE" },
              telephone: PHONE,
              url: "https://asenso-soluciones.example",
              sameAs: [
                "https://www.instagram.com/asenso_soluciones/",
                "https://www.tiktok.com/@asenso_soluciones"
              ],
              description: "Remodelaciones limpias y rápidas: microcemento, drywall, resina epóxica, wallpaper. Asenso Preview 24h con imágenes IA + presupuesto."
            })
          }}
        />
      </Head>

      {/* barra móvil fija */}
      <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-neutral-900/90 backdrop-blur border-t border-neutral-800 p-3 flex gap-3 justify-between items-center">
        <a href={WHATSAPP_URL} className="flex-1 text-center rounded-xl px-4 py-3 bg-sky-500 hover:bg-sky-400 font-semibold">WhatsApp</a>
        <a href={`tel:${PHONE}`} className="rounded-xl px-4 py-3 bg-neutral-800 font-medium">Llamar</a>
      </div>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-500/10 via-neutral-900 to-neutral-950" />
        <div className="relative max-w-6xl mx-auto px-6 pt-20 pb-16 md:pt-28 md:pb-24">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">
                Remodelaciones <span className="text-sky-400">limpias</span> y <span className="text-sky-400">rápidas</span>
                <br />en Gran Caracas
              </h1>
              <p className="mt-5 text-neutral-300 text-lg md:text-xl max-w-xl">
                Microcemento, drywall, resina epóxica y wallpaper.
                <span className="font-semibold"> Asenso Preview 24h</span>: te mostramos con IA cómo quedaría tu espacio y te entregamos presupuesto en 24 horas.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href={WHATSAPP_URL} className="rounded-2xl px-6 py-3 bg-sky-500 hover:bg-sky-400 text-neutral-900 font-semibold shadow-lg">Quiero mi Preview 24h</a>
                <a href="#portafolio" className="rounded-2xl px-6 py-3 bg-neutral-800 hover:bg-neutral-700 font-semibold">Ver antes / después</a>
              </div>
              <ul className="mt-6 grid sm:grid-cols-2 gap-2 text-neutral-300 text-sm">
                <li>• Presupuesto en 24h</li>
                <li>• Precio cerrado + garantía escrita</li>
                <li>• Obras sin demoliciones innecesarias</li>
                <li>• Atención: Caracas, Miranda y La Guaira</li>
              </ul>
            </div>

            {/* logo circular */}
            <div className="rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl flex items-center justify-center bg-neutral-900 p-6">
              <img src="/logo-asenso.png" alt="Asenso Soluciones — logo circular" className="w-56 h-56 object-contain rounded-full border border-neutral-800" />
            </div>
          </div>
        </div>
      </section>

      {/* SERVICIOS */}
      <section id="servicios" className="max-w-6xl mx-auto px-6 py-16 md:py-24">
        <h2 className="text-3xl md:text-4xl font-bold">Servicios</h2>
        <p className="mt-2 text-neutral-300">Soluciones integrales con acabado moderno, mínima molestia y entrega en días.</p>
        <div className="mt-10 grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5">
          {[
            { title: "Microcemento", desc: "Acabado continuo y elegante sin demoliciones; fácil limpieza; ideal para baños, cocinas y locales." },
            { title: "Drywall", desc: "Paredes y techos rápidos con opción de iluminación LED y mejoras acústicas." },
            { title: "Resina Epóxica", desc: "Pisos resistentes, brillantes y de bajo mantenimiento para hogares y comercios." },
            { title: "Wallpaper", desc: "Impacto visual en horas con diseños personalizados y reversibles." },
          ].map((s) => (
            <div key={s.title} className="rounded-2xl border border-neutral-800 bg-neutral-900 p-6 hover:border-sky-500/40 transition">
              <h3 className="text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-neutral-300 text-sm">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* DIFERENCIADORES */}
      <section className="bg-neutral-900/50 border-y border-neutral-800">
        <div className="max-w-6xl mx-auto px-6 py-14 grid md:grid-cols-4 sm:grid-cols-2 gap-6">
          {[
            { t: "Presupuesto 24h", s: "Respuesta rápida por WhatsApp" },
            { t: "Precio cerrado", s: "Sin sorpresas ni extras ocultos" },
            { t: "Obra limpia", s: "Cero escombros innecesarios" },
            { t: "Garantía escrita", s: "Respaldo y mantenimiento básico" },
          ].map((i) => (
            <div key={i.t} className="rounded-2xl p-6 bg-neutral-950 border border-neutral-800">
              <p className="text-lg font-semibold text-sky-400">{i.t}</p>
              <p className="text-neutral-300 mt-1 text-sm">{i.s}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PORTAFOLIO */}
      <section id="portafolio" className="max-w-6xl mx-auto px-6 py-16 md:py-24">
        <div className="flex items-end justify-between gap-4 flex-wrap">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold">Antes / Después</h2>
            <p className="mt-2 text-neutral-300">Casos reales y renders de referencia. Envía tus fotos y generamos tu preview en 24h.</p>
          </div>
          <a href={WHATSAPP_URL} className="rounded-2xl px-5 py-2.5 bg-sky-500 hover:bg-sky-400 text-neutral-900 font-semibold">Quiero mi Preview</a>
        </div>

        <div className="mt-8 grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-5">
          {[
            { src: "/fotos/caracas-bano-microcemento-antes.jpg", alt: "Caracas — baño antes de microcemento — Asenso Soluciones" },
            { src: "/fotos/caracas-bano-microcemento-despues.jpg", alt: "Caracas — baño con microcemento (después) — acabado moderno" },
            { src: "/fotos/miranda-local-drywall-led-antes.jpg", alt: "Miranda — local antes del techo drywall con LED" },
            { src: "/fotos/miranda-local-drywall-led-despues.jpg", alt: "Miranda — techo drywall con iluminación blanca fría (después)" },
            { src: "/fotos/la-guaira-piso-resina-antes.jpg", alt: "La Guaira — piso antes del recubrimiento epóxico" },
            { src: "/fotos/la-guaira-piso-resina-despues.jpg", alt: "La Guaira — piso con resina epóxica, brillo y resistencia" },
          ].map((img, idx) => (
            <figure key={idx} className="relative rounded-3xl overflow-hidden border border-neutral-800 group">
              <img src={img.src} alt={img.alt} className="w-full h-64 object-cover group-hover:scale-105 transition duration-300" />
              {/* watermark */}
              <div className="pointer-events-none absolute inset-0 flex items-end justify-end p-3" style={{ display: WATERMARK ? 'flex' : 'none' }}>
                <img src={LOGO_SRC} alt="Asenso Soluciones watermark" style={{ width: WM_SIZE, height: WM_SIZE, opacity: WM_OPACITY }} />
              </div>
            </figure>
          ))}
        </div>
        <p className="mt-4 text-sm text-neutral-400">/** Reemplaza las rutas por tus fotos reales. Usa nombres SEO: zona + servicio + antes/después. **/</p>
      </section>

      {/* CONTACTO */}
      <section id="contacto" className="max-w-6xl mx-auto px-6 py-16 md:py-24">
        <div className="rounded-3xl border border-neutral-800 bg-neutral-900 p-8 md:p-10 flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
          <div>
            <h3 className="text-2xl md:text-3xl font-bold">Agenda tu Preview 24h</h3>
            <p className="mt-2 text-neutral-300">Gran Caracas (Caracas, Miranda, La Guaira). Atención por WhatsApp y llamada.</p>
            <p className="mt-1 text-neutral-400 text-sm">Tel: <a href={`tel:${PHONE}`} className="underline">{PHONE}</a></p>
          </div>
          <div className="flex gap-3">
            <a href={WHATSAPP_URL} className="rounded-2xl px-6 py-3 bg-sky-500 hover:bg-sky-400 text-neutral-900 font-semibold">WhatsApp</a>
            <a href={`tel:${PHONE}`} className="rounded-2xl px-6 py-3 bg-neutral-800 hover:bg-neutral-700 font-semibold">Llamar</a>
          </div>
        </div>
      </section>

      <footer className="border-t border-neutral-800 py-8">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-neutral-400">
          <p>© {new Date().getFullYear()} Asenso Soluciones — Gran Caracas</p>
          <p>Instagram: <a className="underline" href="https://www.instagram.com/asenso_soluciones/" target="_blank">@asenso_soluciones</a></p>
        </div>
      </footer>
    </main>
  )
}
